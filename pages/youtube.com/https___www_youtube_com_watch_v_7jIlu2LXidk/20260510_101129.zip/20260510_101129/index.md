# Visited: https://www.youtube.com/watch?v=7jIlu2LXidk
**Time:** Sun May 10 10:11:36 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (5 files)
## Downloaded Media Files

- [favicon.ico](./media/favicon.ico) (13 KB)
![favicon_144x144.png](./media/favicon_144x144.png)
![favicon_32x32.png](./media/favicon_32x32.png)
![favicon_48x48.png](./media/favicon_48x48.png)
![favicon_96x96.png](./media/favicon_96x96.png)

## Other Links
- [/](/)
- [//fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=YouTube+Sans:wght@300..900&display=swap](//fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=YouTube+Sans:wght@300..900&display=swap)
- [/manifest.webmanifest](/manifest.webmanifest)
- [/new](/new)
- [/s/player/8fb635c2/player_ias.vflset/en_US/base.js](/s/player/8fb635c2/player_ias.vflset/en_US/base.js)
- [/s/player/8fb635c2/www-player.css](/s/player/8fb635c2/www-player.css)
- [/t/contact_us/](/t/contact_us/)
- [/t/privacy](/t/privacy)
- [/t/terms](/t/terms)
- [android-app://com.google.android.youtube/http/www.youtube.com/watch?v=7jIlu2LXidk](android-app://com.google.android.youtube/http/www.youtube.com/watch?v=7jIlu2LXidk)
- [https://accounts.google.com/ServiceLogin?service=youtube&amp;uilel=3&amp;passive=true&amp;continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3D%252Fsignin_passive%26feature%3Dpassive&amp;hl=en](https://accounts.google.com/ServiceLogin?service=youtube&amp;uilel=3&amp;passive=true&amp;continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3D%252Fsignin_passive%26feature%3Dpassive&amp;hl=en)
- [https://developers.google.com/youtube](https://developers.google.com/youtube)
- [https://m.youtube.com/watch?v=7jIlu2LXidk](https://m.youtube.com/watch?v=7jIlu2LXidk)
- [https://tv.youtube.com/learn/nflsundayticket](https://tv.youtube.com/learn/nflsundayticket)
- [https://www.youtube.com/about/](https://www.youtube.com/about/)
- [https://www.youtube.com/about/copyright/](https://www.youtube.com/about/copyright/)
- [https://www.youtube.com/about/policies/](https://www.youtube.com/about/policies/)
- [https://www.youtube.com/about/press/](https://www.youtube.com/about/press/)
- [https://www.youtube.com/ads/](https://www.youtube.com/ads/)
- [https://www.youtube.com/creators/](https://www.youtube.com/creators/)
- [https://www.youtube.com/howyoutubeworks?utm_campaign=ytgen&amp;utm_source=ythp&amp;utm_medium=LeftNav&amp;utm_content=txt&amp;u=https%3A%2F%2Fwww.youtube.com%2Fhowyoutubeworks%3Futm_source%3Dythp%26utm_medium%3DLeftNav%26utm_campaign%3Dytgen](https://www.youtube.com/howyoutubeworks?utm_campaign=ytgen&amp;utm_source=ythp&amp;utm_medium=LeftNav&amp;utm_content=txt&amp;u=https%3A%2F%2Fwww.youtube.com%2Fhowyoutubeworks%3Futm_source%3Dythp%26utm_medium%3DLeftNav%26utm_campaign%3Dytgen)
- [https://www.youtube.com/opensearch?locale=en_US](https://www.youtube.com/opensearch?locale=en_US)
- [https://www.youtube.com/s/_/ytmainappweb/_/js/k=ytmainappweb.kevlar.en_US.8wiN22Q0Mcs.es5.O/am=AAAAAAQAEEg/d=1/rs=AGKMywGDAz8gXkXQ4IxB4w_LRIxsVXiW1A/m=root_chunk,base_chunk,main_chunk,kevlar_sync_mod_chunk](https://www.youtube.com/s/_/ytmainappweb/_/js/k=ytmainappweb.kevlar.en_US.8wiN22Q0Mcs.es5.O/am=AAAAAAQAEEg/d=1/rs=AGKMywGDAz8gXkXQ4IxB4w_LRIxsVXiW1A/m=root_chunk,base_chunk,main_chunk,kevlar_sync_mod_chunk)
- [https://www.youtube.com/s/_/ytmainappweb/_/ss/k=ytmainappweb.kevlar.qtGqkd01sq8.L.X.O/am=AAAAAAQgEEw/d=0/rs=AGKMywGksoxDlANnIFIHtEqqeeZ-7BBqIw](https://www.youtube.com/s/_/ytmainappweb/_/ss/k=ytmainappweb.kevlar.qtGqkd01sq8.L.X.O/am=AAAAAAQgEEw/d=0/rs=AGKMywGksoxDlANnIFIHtEqqeeZ-7BBqIw)
- [https://www.youtube.com/s/desktop/14cba078/cssbin/www-main-desktop-player-skeleton.css](https://www.youtube.com/s/desktop/14cba078/cssbin/www-main-desktop-player-skeleton.css)
- [https://www.youtube.com/s/desktop/14cba078/cssbin/www-main-desktop-watch-page-skeleton.css](https://www.youtube.com/s/desktop/14cba078/cssbin/www-main-desktop-watch-page-skeleton.css)
- [https://www.youtube.com/s/desktop/14cba078/cssbin/www-onepick.css](https://www.youtube.com/s/desktop/14cba078/cssbin/www-onepick.css)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/fetch-polyfill.vflset/fetch-polyfill.js](https://www.youtube.com/s/desktop/14cba078/jsbin/fetch-polyfill.vflset/fetch-polyfill.js)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/intersection-observer.min.vflset/intersection-observer.min.js](https://www.youtube.com/s/desktop/14cba078/jsbin/intersection-observer.min.vflset/intersection-observer.min.js)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/network.vflset/network.js](https://www.youtube.com/s/desktop/14cba078/jsbin/network.vflset/network.js)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/scheduler.vflset/scheduler.js](https://www.youtube.com/s/desktop/14cba078/jsbin/scheduler.vflset/scheduler.js)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/spf.vflset/spf.js](https://www.youtube.com/s/desktop/14cba078/jsbin/spf.vflset/spf.js)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/web-animations-next-lite.min.vflset/web-animations-next-lite.min.js](https://www.youtube.com/s/desktop/14cba078/jsbin/web-animations-next-lite.min.vflset/web-animations-next-lite.min.js)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/webcomponents-all-noPatch.vflset/webcomponents-all-noPatch.js](https://www.youtube.com/s/desktop/14cba078/jsbin/webcomponents-all-noPatch.vflset/webcomponents-all-noPatch.js)
- [https://www.youtube.com/s/desktop/14cba078/jsbin/www-i18n-constants-en_US.vflset/www-i18n-constants.js](https://www.youtube.com/s/desktop/14cba078/jsbin/www-i18n-constants-en_US.vflset/www-i18n-constants.js)
- [ios-app://544007664/vnd.youtube/www.youtube.com/watch?v=7jIlu2LXidk](ios-app://544007664/vnd.youtube/www.youtube.com/watch?v=7jIlu2LXidk)
- [undefined](undefined)

## Stats
- Links: 42
- Media: 5
